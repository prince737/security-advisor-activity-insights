#!/bin/bash

if [ "$#" -ne 4 ]; then
  echo "Required arguments missing!"
  echo "Usage : ./activity-insight-install.sh <cos_region> <cos_api_key> <at_region> <at_service_api_key>"
  echo "<cos_region> region in which your COS instance is deployed, value is either us-south or eu-gb"
  echo "<cos_api_key> is the api key present in COS service credentials"
  echo "<at_region> is the region of the logDNA AT instance"
  echo "<at_service_api_key> is a logDNA AT instance service key"
  exit 1
fi

cos_region=$1
cos_api_key=$2
at_region=$3
at_service_api_key=$4

cos_endpoint="https://s3.$cos_region.cloud-object-storage.appdomain.cloud"
iam_base_url="https://iam.cloud.ibm.com"
at_base_url="https://api.$at_region.logging.cloud.ibm.com"
cos_ibm_auth_endpoint="https://iam.cloud.ibm.com/oidc/token"

# Don't run if any of the prerequisites are not installed.
prerequisites=( "yq" "kubectl" "helm" "curl")
for i in "${prerequisites[@]}"
do
  isExist=$(command -v $i)
  if [ -z "$isExist" ]
  then
    echo "$i not installed. Please install the required pre-requisites first (yq, kubectl, helm, curl)"
    exit 1
  fi
done

# Get cluster info
kubectl get cm cluster-info -n kube-system -o yaml | yq r - data[cluster-config.json] > cluster-config.yaml
account_id=$(yq r cluster-config.yaml | yq r - account_id)
cos_bucket="sa.$account_id.telemetric.$cos_region"
subnet=""

# Check for the OS type and set executable accordingly.
osType=$(uname)
if [ "$osType" = "Linux" ]
then
  # Running on a Linux variant.
  encode="base64 -w 0"
else
  # Running on macOS.
  encode="base64"
fi

ACCESS_TOKEN=$(curl -s -X POST \
-H "Content-Type: application/x-www-form-urlencoded" \
-H "Accept: application/json" \
-d "grant_type=urn%3Aibm%3Aparams%3Aoauth%3Agrant-type%3Aapikey&apikey=$cos_api_key" \
"$iam_base_url/identity/token" | yq r - access_token)

bucketStatus=$(curl -s -X GET -H "Authorization: Bearer $ACCESS_TOKEN" $cos_endpoint/$cos_bucket)
if [[ "$bucketStatus" =~ "The specified bucket does not exist" ]]; then
    echo "Bucket $cos_bucket does not exists. Please create one using the Security Advisor UI"
    exit 1
fi

at_region_encoded=$(echo -n $at_region | $encode)
cos_api_key_encoded=$(echo -n $cos_api_key | $encode)
cos_bucket_encoded=$(echo -n $cos_bucket | $encode)
cos_endpoint_encoded=$(echo -n $cos_endpoint | $encode)
iam_base_url_encoded=$(echo -n $iam_base_url | $encode)
at_base_url_encoded=$(echo -n $at_base_url | $encode)
at_service_api_key_encoded=$(echo -n $at_service_api_key | $encode)
cos_ibm_auth_endpoint_encoded=$(echo -n $cos_ibm_auth_endpoint | $encode)

yq w -i activity-insights-chart/secret-template.yaml data.iam_base_url $iam_base_url_encoded
yq w -i activity-insights-chart/secret-template.yaml data.at_base_url $at_base_url_encoded
yq w -i activity-insights-chart/secret-template.yaml data.at_region $at_region_encoded
yq w -i activity-insights-chart/secret-template.yaml data.at_service_api_key $at_service_api_key_encoded
yq w -i activity-insights-chart/secret-template.yaml data.cos_api_key $cos_api_key_encoded
yq w -i activity-insights-chart/secret-template.yaml data.cos_bucket $cos_bucket_encoded
yq w -i activity-insights-chart/secret-template.yaml data.cos_endpoint $cos_endpoint_encoded
yq w -i activity-insights-chart/secret-template.yaml data.cos_ibm_auth_endpoint $cos_ibm_auth_endpoint_encoded

tls='--tls'
enabled='N'
tlsStatus=$(helm ls 2>&1)
if [[ "$tlsStatus" != "Error: transport is closing" ]]; then
    read -p 'Warning: Helm TLS is not enabled. Do you want to continue? [y/N] ' enabled
    if [ "$enabled" == "y" ]
    then
        helm init
        echo "Sleeping for 10 seconds so that tiller pod is ready"
        sleep 10
        tls=''
    else
        echo "Setup helm TLS. Follow https://github.com/helm/helm/blob/master/docs/tiller_ssl.md"
        exit 1
    fi
fi

# kubectl create namespace security-advisor-insights
nsCreateCmd=$(kubectl create namespace security-advisor-insights 2>&1)
if [[ "$nsCreateCmd" =~ "already exists" ]]; then
    echo "Warning: Namespace 'security-advisor-insights' already exist. Proceeding with the same."
else
    echo "Namespace 'security-advisor-insights' created successfully"
fi

bluemixSecretCreateCmd=$(kubectl  get secret  bluemix-default-secret-international  -o yaml | sed "s/default/security-advisor-insights/g" | kubectl -n security-advisor-insights  create -f - 2>&1)

if [[ "$bluemixSecretCreateCmd" =~ "created" ]]; then
    echo "Secret 'bluemix-security-advisor-insights-secret-international' created successfully"
elif [[ "$bluemixSecretCreateCmd" =~ "already exists" ]]; then
    echo "Secret 'bluemix-security-advisor-insights-secret-international' exists"
else
    echo "Error creating secret 'bluemix-security-advisor-insights-secret-international'"
    exit 1
fi

chartDeployCmd=$(kubectl apply -f activity-insights-chart/secret-template.yaml)
if [[ $chartDeployCmd ]]; then
    echo "Secret 'activity-insights-secret' created successfully. Please check 'activity-insights-chart/secret-template.yaml'"
else
    echo "Error creating secret 'activity-insights-secret'"
    exit 1
fi

helmInstallCmd=$(helm install $tls -n activity-insights activity-insights-chart --namespace security-advisor-insights --wait --timeout 400 2>&1)
helmStatus=$(helm status activity-insights -o json $tls | yq r - info.status.code)
if [[ "$helmStatus" == "1" && "$helmInstallCmd" != *"Error"* ]]; then
    echo "Activity insights helm chart installation successful!"
else
    echo "$helmInstallCmd"
    echo "Activity insights helm chart installation Failed!"
fi
