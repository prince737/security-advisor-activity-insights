#!/bin/bash

if [ "$#" -lt 5 ] || [ "$#" -gt 7 ]; then
	echo "Required arguments missing!"
	echo "Usage : ./activity-insight-install.sh <cos_region> <cos_api_key> <at_region> <at_service_api_key>"
	echo "<cos_region> region in which your COS instance is deployed, value is either us-south or eu-gb"
	echo "<cos_api_key> is the api key present in COS service credentials"
	echo "<cos_bucket> is the COS bucket in your COS instance"
	echo "<at_region> is the region of the logDNA AT instance"
	echo "<at_service_api_key> is a logDNA AT instance service key"
	echo "optional : <default_memory_request> is default memory assigned to container"
	echo "optional : <memory_limit> is memory limit for container"
	exit 1
fi

cos_region=$1
cos_api_key=$2
cos_bucket=$3
at_region=$4
at_service_api_key=$5

cos_endpoint="https://s3.$cos_region.cloud-object-storage.appdomain.cloud"
iam_base_url="https://iam.cloud.ibm.com"
at_base_url="https://api.$at_region.logging.cloud.ibm.com"
cos_ibm_auth_endpoint="https://iam.cloud.ibm.com/oidc/token"

# Don't run if any of the prerequisites are not installed.
prerequisites=("yq" "kubectl" "helm" "curl")
for i in "${prerequisites[@]}"; do
	isExist=$(command -v $i)
	if [ -z "$isExist" ]; then
		echo "$i not installed. Please install the required pre-requisites first (yq, kubectl, helm, curl)"
		exit 1
	fi
done

# Get cluster info
kubectl get cm cluster-info -n kube-system -o yaml | yq r - data[cluster-config.json] >cluster-config.yaml
account_id=$(yq r cluster-config.yaml | yq r - account_id)
cluster_type=$(yq r cluster-config.yaml | yq r - cluster_type)
cluster_name=$(yq r cluster-config.yaml | yq r - name)
subnet=""

# Check for the OS type and set executable accordingly.
osType=$(uname)
if [ "$osType" = "Linux" ]; then
	# Running on a Linux variant.
	encode="base64 -w 0"
else
	# Running on macOS.
	encode="base64"
fi

#if installing in  vpc cluster
if [[ $cluster_type == *"vpc"* ]]; then
    #echo "Installing Activity Insights in VPC cluster $cluster_name"
    #cos_endpoint="https://s3.direct.$cos_region.cloud-object-storage.appdomain.cloud"
    #at_base_url="https://api.private.$at_region.logging.cloud.ibm.com"
    echo "Built-in insights are available for Kubernetes clusters on classic infrastructure only."
    exit 1	
else
    echo "Installing Activity Insights in classic cluster $cluster_name"
fi

ACCESS_TOKEN=$(curl -s -X POST \
	-H "Content-Type: application/x-www-form-urlencoded" \
	-H "Accept: application/json" \
	-d "grant_type=urn%3Aibm%3Aparams%3Aoauth%3Agrant-type%3Aapikey&apikey=$cos_api_key" \
	"$iam_base_url/identity/token" | yq r - access_token)

bucketStatus=$(curl -s -X GET -H "Authorization: Bearer $ACCESS_TOKEN" $cos_endpoint/$cos_bucket)
if [[ "$bucketStatus" =~ "The specified bucket does not exist" ]]; then
	echo "Bucket $cos_bucket does not exists. Please create one using the Security Advisor UI"
	exit 1
fi

at_region_encoded=$(echo -n $at_region | $encode)
cos_api_key_encoded=$(echo -n $cos_api_key | $encode)
cos_bucket_encoded=$(echo -n $cos_bucket | $encode)
cos_endpoint_encoded=$(echo -n $cos_endpoint | $encode)
iam_base_url_encoded=$(echo -n $iam_base_url | $encode)
at_base_url_encoded=$(echo -n $at_base_url | $encode)
at_service_api_key_encoded=$(echo -n $at_service_api_key | $encode)
cos_ibm_auth_endpoint_encoded=$(echo -n $cos_ibm_auth_endpoint | $encode)

yq w -i activity-insights-chart/secret-template.yaml data.iam_base_url $iam_base_url_encoded
yq w -i activity-insights-chart/secret-template.yaml data.at_base_url $at_base_url_encoded
yq w -i activity-insights-chart/secret-template.yaml data.at_region $at_region_encoded
yq w -i activity-insights-chart/secret-template.yaml data.at_service_api_key $at_service_api_key_encoded
yq w -i activity-insights-chart/secret-template.yaml data.cos_api_key $cos_api_key_encoded
yq w -i activity-insights-chart/secret-template.yaml data.cos_bucket $cos_bucket_encoded
yq w -i activity-insights-chart/secret-template.yaml data.cos_endpoint $cos_endpoint_encoded
yq w -i activity-insights-chart/secret-template.yaml data.cos_ibm_auth_endpoint $cos_ibm_auth_endpoint_encoded

tls='--tls'
enabled='N'
tlsStatus=$(helm ls 2>&1)
if [[ "$tlsStatus" != "Error: transport is closing" ]]; then
	read -p 'Warning: Helm TLS is not enabled. Do you want to continue? [y/N] ' enabled
	if [ "$enabled" == "y" ]; then
		helm init
		echo "Sleeping for 10 seconds so that tiller pod is ready"
		sleep 10
		tls=''
	else
		echo "Setup helm TLS. Follow https://github.com/helm/helm/blob/master/docs/tiller_ssl.md"
		exit 1
	fi
fi

# kubectl create namespace security-advisor-activity-insights
namespace="security-advisor-activity-insights"
nsCreateCmd=$(kubectl create namespace $namespace 2>&1)
if [[ "$nsCreateCmd" =~ "already exists" ]]; then
	echo "Warning: Namespace $namespace already exist. Proceeding with the same."
else
	echo "Namespace $namespace created successfully"
fi

copyFromSecret="default-icr-io"
secretName="ibmcloud-security-advisor-activity-insights-icr-io"
secretCommand=$(kubectl get secret $copyFromSecret -o yaml | sed "s/$copyFromSecret/$secretName/g" | sed "s/default/$namespace/g" | kubectl -n $namespace create -f - 2>&1)

if [[ "$secretCommand" =~ "created" ]]; then
	echo "Secret $secretName created successfully"
elif [[ "$secretCommand" =~ "already exists" ]]; then
	echo "Secret $secretName exists"
else
	echo "Error creating secret $secretName"
	exit 1
fi

#default memory limits for pod
default_memory_request='256Mi'
memory_limit='512Mi'
limit_range_name="activity-insights-limit-range"

if [ "$#" = 6 ]; then
  #set only default memory , limit will be 512Mi
  default_memory_request=$6
fi

if [ "$#" = 7 ]; then
  #set user defined memory limits for pod
  default_memory_request=$6
  memory_limit=$7
fi


yq w -i activity-insights-chart/limitrange-template.yaml spec.limits[0].defaultRequest.memory $default_memory_request
yq w -i activity-insights-chart/limitrange-template.yaml spec.limits[0].default.memory $memory_limit

createLimitRangeCmd=$(kubectl apply -f activity-insights-chart/limitrange-template.yaml)
if [[ $? == 0 ]]; then
	echo "POD will be created with default memory $default_memory_request and maximum memory $memory_limit"
else
	echo "Error creating limitrange $limit_range_name"
	exit 1
fi


chartDeployCmd=$(kubectl apply -f activity-insights-chart/secret-template.yaml)
if [[ $chartDeployCmd ]]; then
	echo "Secret 'activity-insights-secret' created successfully. Please check 'activity-insights-chart/secret-template.yaml'"
else
	echo "Error creating secret 'activity-insights-secret'"
	exit 1
fi

helmInstallCmd=$(helm install $tls -n activity-insights activity-insights-chart --namespace $namespace --wait --timeout 400 2>&1)
helmStatus=$(helm status activity-insights -o json $tls | yq r - info.status.code)
if [[ "$helmStatus" == "1" && "$helmInstallCmd" != *"Error"* ]]; then
	echo "Activity insights helm chart installation successful!"
else
	echo "$helmInstallCmd"
	echo "Activity insights helm chart installation Failed!"
fi
